const BMIEntity = require("./bmi-entity");

const bmi = new BMIEntity();

module.exports = {
    bmi
}